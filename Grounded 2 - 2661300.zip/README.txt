👻GhostDepots👻
This lua file has been fetched from the bot Ghost which is property of GhostDepots 👻
Redistribution of Ghosts files is not allowed AT ALL!
Join the official here: https://discord.gg/GhostDepots
👻👻👻👻👻👻👻👻👻👻👻👻👻👻👻👻👻👻👻👻👻👻👻👻

ID: cf0acb59-68c6-4ac1-a1bc-e7a73d7024ac
Checksum (SHA256): b47f09afa4077c7e216d813a9b07d7ff139c2558cab36a24b62f8f8203eacfa9