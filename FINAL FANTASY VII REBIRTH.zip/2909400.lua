-- manifest & lua provided by: https://www.piracybound.com/discord
-- via manilua
addappid(2909400)
addappid(2909401, 1, "7ab31662f5cf76b4197f27c340a2a0589dc4713c137aadfd22b281df42c07a56")
setManifestid(2909401, "8207554222399244974", 0)
addappid(2909402, 1, "fd15686ace81b2e7a839997e1bcc40d7dd9c15f49ce21714252771aa357fd67f")
setManifestid(2909402, "885019631141671181", 0)

addappid(3376810) -- FINAL FANTASY VII REBIRTH Accessory: Kupo Charm & Survival Set
addappid(3361450) -- FINAL FANTASY VII REBIRTH Digital Deluxe Edition Upgrade
addappid(3312280) -- FINAL FANTASY VII REBIRTH Armor: Midgar Bangle Mk. II
addappid(3312270) -- FINAL FANTASY VII REBIRTH Armor: Shinra Bangle Mk. II
addappid(3312260) -- FINAL FANTASY VII REBIRTH Posh Chocobo Summoning Materia
addappid(3260680) -- FINAL FANTASY VII REBIRTH Armor: Orchid Bracelet
addappid(3260670) -- FINAL FANTASY VII REBIRTH Accessory: Reclaimant Choker
addappid(3260660) -- FINAL FANTASY VII REBIRTH Summon materia: Magic Pot
addappid(3260650) -- FINAL FANTASY VII REBIRTH Summon materia: Moogle trio