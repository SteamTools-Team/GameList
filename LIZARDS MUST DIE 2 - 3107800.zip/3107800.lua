addappid(3107800)
addappid(3107801,0,"890f21e1179fb55405d9a3e26c308dd7671d612e5d67f6ae07ff9e9f4ac92c14")
setManifestid(3107801,"7625288491920022004")



--[[
This file belongs to Ahmeds Bot Discord Server
-----> join discord Server : https://discord.gg/sv6EGxCRnC
]]