addappid(3430450)
addappid(3430451,0,"d6332436b602f2c28d7293d6ed4ff8c47276e5035de5e2f55b3049ccd5f1e948")
setManifestid(3430451,"3801121280577689738")





--[[
This file belongs to Ahmeds Bot Discord Server
-----> join discord Server : https://discord.gg/sv6EGxCRnC
]]