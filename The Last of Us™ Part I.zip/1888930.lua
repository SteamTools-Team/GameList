-- manifest & lua provided by: https://www.piracybound.com/discord
-- via manilua
addappid(1888930)
addappid(1888931, 1, "19cd197b4bc7e62551196ec84d00da135a4dedeb5edca50804001bf9e90b6b70")
setManifestid(1888931, "7149537440347319468", 0)
addappid(1888932, 1, "20a675f9d2a0efd0cf0f8985b2a1c67d5d64e1c2b5aee665d3692969b28b1be4")
setManifestid(1888932, "7992746905878846452", 0)

addappid(2254450) -- The Last of Us™ Part I - Upgrade to Digital Deluxe Edition
addappid(2245260) -- The Last of Us™ Part I - Pre-purchase Entitlements