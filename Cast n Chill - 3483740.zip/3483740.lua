addappid(3483740)
addappid(3483741,0,"0085e2ab6e91d273c72748b41db876429a43a28e359be3bd5519ddfa4d8ac501")
setManifestid(3483741,"5456948244804082422")




--[[
This file belongs to Ahmeds Bot Discord Server
-----> join discord Server : https://discord.gg/sv6EGxCRnC
]]