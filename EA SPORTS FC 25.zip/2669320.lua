-- manifest & lua provided by: https://www.piracybound.com/discord
-- via manilua
addappid(2669320)
addappid(2669321,1,"76cc370335c7af8b640b995822f72e2a526e593b8b0e415ffee6b14269c110f2")
setManifestid(2669321,"4676266760364372559",0)
addappid(2669328,1,"afda87b077dfe9ffd05d8d16286646f99eefd1d5317eea27397b157a51513773")
setManifestid(2669328,"6606981512332674747",0)

-- dlc
addappid(3170610) -- EA SPORTS FC™ 25 - FC Points
addappid(3102940) -- EA SPORTS FC™ 25
addappid(2898380) -- FC 25 - Press Offer Key
addappid(2898370) -- FC 25 - EA Play Trial Key
addappid(2898360) -- EA SPORTS FC™ 25 Ultimate Edition Pre-Purchase
addappid(2898350) -- EA SPORTS FC™ 25 Ultimate Edition Pre-Purchase content
addappid(2898340) -- EA SPORTS FC™ 25 Standard Edition Pre-Purchase content
addappid(2898330) -- EA SPORTS FC™ 25 Ultimate Edition Content
addappid(2680690) -- EA SPORTS FC™ 25 - Key