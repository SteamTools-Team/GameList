👻GhostDepots👻
This lua file has been fetched from the bot Ghost which is property of GhostDepots 👻
Redistribution of Ghosts files is not allowed AT ALL!
Join the official here: https://discord.gg/GhostDepots
👻👻👻👻👻👻👻👻👻👻👻👻👻👻👻👻👻👻👻👻👻👻👻👻

ID: 3c4bc353-13f2-4c87-960f-d4387c474287
Checksum (SHA256): ad66568ecc93f08e275f4e41c4946bbddeb30ab147ef52d9151bfb0823528649