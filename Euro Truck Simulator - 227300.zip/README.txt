👻GhostDepots👻
This lua file has been fetched from the bot Ghost which is property of GhostDepots 👻
Redistribution of Ghosts files is not allowed AT ALL!
Join the official here: https://discord.gg/GhostDepots
👻👻👻👻👻👻👻👻👻👻👻👻👻👻👻👻👻👻👻👻👻👻👻👻

ID: 4b6bb371-84ed-4597-a6ce-e29b69f4bf79
Checksum (SHA256): 484abaaae9112f26dae3b3a5f0a38e1e7348b774e3ec3e32d13fecd8f6ced390