-- manifest & lua provided by: https://www.piracybound.com/discord
-- via manilua
addappid(2456740)
addappid(2456741, 1, "e91cba2d1d471bdfb115bee76ac997858f84e6ab0a82af5f17d0054f8a3c9686")
setManifestid(2456741, "8321490079515316932", 0)
