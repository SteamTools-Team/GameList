-- manifest & lua provided by: https://www.piracybound.com/discord
-- via manilua
addappid(2050650)
addappid(2050651, 1, "c3bc4be6ae2c98c50f2ba78469906e43be35b408daf8d49f420aaf6cad275b2b")
setManifestid(2050651, "8614591153569085301", 0)
addappid(2050653, 1, "219060cb9daf307498b27b009af1468282599d2d3fdf2b23729c0bd833b84053")
setManifestid(2050653, "4756862649215238992", 0)
addappid(2109301, 1, "d2ec1b74333218e11dc8471f4e2057fd825d407a4c47dfc646df60881a5841b9") -- Resident Evil 4 Treasure Map: Expansion
setManifestid(2109301, "360070119915724610", 0)
addappid(2109303, 1, "5bf57eede21276d7dbab353eb7272c6e6a7ffca40fd535337f8b64dc1f7df1c0") -- Resident Evil 4 Leon & Ashley Costumes: 'Casual'
setManifestid(2109303, "9166301326971889287", 0)
addappid(2109304, 1, "3d8963f6736172da45ac32e19df3078f2cb2679f4a34cb0b70970e183241ebd3") -- Resident Evil 4 Leon & Ashley Costumes: 'Romantic'
setManifestid(2109304, "382218590876545051", 0)
addappid(2109305, 1, "7df756b7ea77cd773635eaba56572deb90e4518e52b0620d47c9cc8ed10b1798") -- Resident Evil 4 Leon Costume & Filter: 'Hero'
setManifestid(2109305, "8874053015552356169", 0)
addappid(2109306, 1, "5b1eb1787a6d0500e6cb23a33b19e593c998a07341c04525c9aa0e608d4796ca") -- Resident Evil 4 Leon Costume & Filter: 'Villain'
setManifestid(2109306, "6308526370650425368", 0)
addappid(2109307, 1, "cec2c4f51874f8b5d2dc936e3514bc3c6ce3cd790a609e711d1b5be1fc1159d4") -- Resident Evil 4 'Original Ver.' Soundtrack Swap
setManifestid(2109307, "5310837729215635277", 0)
addappid(2109308, 1, "cae75fb7131ee6918d86a2ba6b4195e729f93fc11291da373fe66dcfe72856ee") -- Resident Evil 4 Deluxe Weapon: 'Sentinel Nine'
setManifestid(2109308, "964709411673088664", 0)
addappid(2109309, 1, "8e04a74054c1ecc380723dbed552ab381ea28d8abfef53011f2c42e4989594f9") -- Resident Evil 4 Deluxe Weapon: 'Skull Shaker'
setManifestid(2109309, "2339425891140016912", 0)
addappid(2109310, 1, "75ed1eef5aa69f5795bf6d3a5f859964fcbbceb43e3fd401f12f52c1b2801b30") -- Resident Evil 4 Leon Accessory: 'Sunglasses (Sporty)'
setManifestid(2109310, "6423275757951298947", 0)