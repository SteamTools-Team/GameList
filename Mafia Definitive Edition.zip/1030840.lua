-- manifest & lua provided by: https://www.piracybound.com/discord
-- via manilua
addappid(1030840)
addappid(1030841, 1, "d6e79f53321a7947e8963e27e1baefb862ce738eb51a2fa8eeaa90c476917f64")
setManifestid(1030841, "2886022585972111903", 0)
addappid(1523211, 1, "6111b2e3d21efa5e5b26a91f75ff32d12aa8c5bb547c4d0215eda184a7f4c49b")
setManifestid(1523211, "8432503686873209246", 0)
