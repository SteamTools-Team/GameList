-- manifest & lua provided by: https://www.piracybound.com/discord
-- via manilua
addappid(2527500)
addappid(2527501,0,"ffef2d1f42cd2438f5b7d029d771a9f941fd224250c3184f595773fb4926e1cd")
setManifestid(2527501,"2651971051393432762")