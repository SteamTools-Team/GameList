addappid(2655590)
addappid(2655591,0,"938cf7542d29fddb19cc588a978b2bcabbf645729522dfbd8d3c2a87e9341e8c")
setManifestid(2655591,"4810441880064554079")



--[[
This file belongs to Ahmeds Bot Discord Server
-----> join discord Server : https://discord.gg/sv6EGxCRnC
]]