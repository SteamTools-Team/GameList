👻GhostDepots👻
This lua file has been fetched from the bot Ghost which is property of GhostDepots 👻
Redistribution of Ghosts files is not allowed AT ALL!
Join the official here: https://discord.gg/GhostDepots
👻👻👻👻👻👻👻👻👻👻👻👻👻👻👻👻👻👻👻👻👻👻👻👻

ID: 4777d9ea-fbac-4aad-bc5d-0624a6f0785d
Checksum (SHA256): db89a6260bd97b076b4b28cf587ef42e76ce99257466c6319ac4ab7d928e2e23