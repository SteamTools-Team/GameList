👻GhostDepots👻
This lua file has been fetched from the bot Ghost which is property of GhostDepots 👻
Redistribution of Ghosts files is not allowed AT ALL!
Join the official here: https://discord.gg/GhostDepots
👻👻👻👻👻👻👻👻👻👻👻👻👻👻👻👻👻👻👻👻👻👻👻👻

ID: 9cc1437c-f7b3-4285-890e-3f4e67ee1b97
Checksum (SHA256): 79506b100dae057dca5e1ffa434da21e3a32b9abbc2404da748ef86196a5a268