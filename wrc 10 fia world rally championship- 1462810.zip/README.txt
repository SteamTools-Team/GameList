👻GhostDepots👻
This lua file has been fetched from the bot Ghost which is property of GhostDepots 👻
Redistribution of Ghosts files is not allowed AT ALL!
Join the official here: https://discord.gg/GhostDepots
👻👻👻👻👻👻👻👻👻👻👻👻👻👻👻👻👻👻👻👻👻👻👻👻

ID: 0d1e42c6-b450-4f46-8dd8-4304729f591d
Checksum (SHA256): 51e97e617cc978454efd962b11a466912c034cd2988305b162c5aea7a0ab65de