addappid(3527290)
addappid(3527291,0,"f55585bb6a00ba332421256f80ba05e27afc38fec6170b9a763138244c506f05")
setManifestid(3527291,"1786827858954525980")





--[[
This file belongs to Ahmeds Bot Discord Server
-----> join discord Server : https://discord.gg/sv6EGxCRnC
]]