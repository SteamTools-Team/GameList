-- manifest & lua provided by: https://www.piracybound.com/discord
-- via manilua
addappid(221100)
addappid(221101, 1, "9D9C5D3D77309BBE701A3F018CEA877D22D07160B4EA2B65BDF261D0DC399C15")
setManifestid(221101, "3309608757320055497", 0)
